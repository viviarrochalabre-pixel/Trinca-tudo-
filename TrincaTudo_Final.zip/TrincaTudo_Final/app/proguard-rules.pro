# Trinca Tudo: no custom shrinking rules required.
