# Trinca Tudo — versão final do projeto Android

Projeto Android completo com:
- Treino Full Body A/B/C
- Registro de cargas e evolução local
- Cronômetro de descanso
- Banner AdMob
- Anúncios de teste no debug e bloco de produção no release
- Botão Premium ligado ao link de pagamento do Mercado Pago fornecido pelo proprietário
- WebView com interface do Trinca Tudo

Package: `com.trincatudo.app`
Version: `1.0` (versionCode 1)

## Para gerar o APK
Abra a pasta no Android Studio e use Build > Generate App Bundles or APKs > Generate APKs.

Observação: este pacote contém o código-fonte completo, mas a assinatura final de publicação precisa ser feita com uma chave de assinatura do proprietário.
